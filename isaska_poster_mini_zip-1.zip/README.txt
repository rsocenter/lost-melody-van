Másold ki ezt a poster.jpg fájlt és cseréld le a meglévő poster.jpg-t a GitHub projektedben, majd commit/push.
